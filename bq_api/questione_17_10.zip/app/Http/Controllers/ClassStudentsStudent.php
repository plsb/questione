<?php

namespace App\Http\Controllers;

use App\ClassQuestione;
use App\ClassStudents;
use App\Http\Controllers\Gamification\PointSystemController;
use Illuminate\Http\Request;
use Validator;

class ClassStudentsStudent extends Controller
{
    private $rules = [
        'id_class' => 'required',

    ];

    private $messages = [
        'id_class.required' => 'O código da Turma é obrigatório.',
    ];

    public function __construct()
    {
        $this->middleware(['jwt.auth']);
    }

    public function index(Request $request)
    {
        $user = auth('api')->user();

        $class_students_student = ClassStudents::where('fk_user_id',$user->id)
            ->get();

        if(sizeof($class_students_student)==0){
            return response()->json([
                'message' => 'O usuário não possui turmas.'
            ], 202);
        }

        $arr = array();
        foreach ($class_students_student as $class_s){
            //dd($enaq);
            $arr[] = $class_s->fk_class_id;
        }

        $class = [];

        if($request->description){
            $class = ClassQuestione::whereIn('id', $arr)
                ->where(
                    function ($query) use ($request) {
                        $query->where('description', 'like', $request->description ? '%'.$request->description.'%' : null);
                    })
                ->orderBy('created_at', 'desc')
                ->with('course')
                ->with('user')
                ->with('class_student')
                ->with('class_student_all')
                ->paginate(10);
        } else {
            $class = ClassQuestione::whereIn('id', $arr)
                ->orderBy('created_at', 'desc')
                ->with('course')
                ->with('user')
                ->with('class_student')
                ->with('class_student_all')
                ->paginate(10);
        }

        return response()->json($class, 200);
    }

    //adicionar uma nova turma
    public function store(Request $request)
    {

        $validation = Validator::make($request->all(), $this->rules, $this->messages);

        if ($validation->fails()) {
            $erros = array('errors' => array(
                $validation->messages()
            ));
            $json_str = json_encode($erros);
            return response($json_str, 202);
        }

        $class_verify = ClassQuestione::where('id_class', $request->id_class)->first();

        if (!$class_verify) {
            return response()->json([
                'message' => 'A Turma não foi encontrada.'
            ], 202);
        }

        $user = auth('api')->user();

        if($class_verify->fk_user_id == $user->id){
            return response()->json([
                'message' => 'A Turma pertence ao usuário ativo.'
            ], 202);
        }

        $class_students_student_verify = ClassStudents::where('fk_user_id', $user->id)
            ->where('fk_class_id', $class_verify->id)
            ->first();

        if($class_students_student_verify){
            return response()->json([
                'message' => 'O usuário já está cadastrado na turma.'
            ], 202);
        }

        $class_students_student = new ClassStudents();
        $class_students_student->fk_user_id = $user->id;
        $class_students_student->fk_class_id = $class_verify->id;
        $class_students_student->active = 0;
        $class_students_student->save();

        //pontuação XP ao entrar em uma sala de aula
        $pointSystem = new PointSystemController();
        $pointSystem->RPpoint('enter_class', $class_verify->id, null, null, null);

        return response()->json([
            'message' => 'Inscrição realizada.',
            $class_students_student
        ], 200);
    }

    //trazer informações (nome de professores e alunos) da turma
    public function show($id)
    {
        $user = auth('api')->user();

        $class = ClassQuestione::where('id', '=', $id)
            ->with('user')
            ->with('course')
            ->with('class_student_all')
            ->first();
        if(!$class){
            return response()->json([
                'message' => 'Turma não encontrada.'
            ], 202);
        }

        $classStudent = ClassStudents::where('fk_user_id', $user->id)
            ->where('fk_class_id', $class->id)->first();

        return response()->json( $class, 200);


    }

    //deleta uma turma, caso o aluno não possua dados de questionários
    public function destroy($id)
    {

        $class_students_student = ClassStudents::find($id);

        if (!$class_students_student) {
            return response()->json([
                'message' => 'A inscrição do aluno não foi encontrada.'
            ], 202);
        }

        $user = auth('api')->user();
        if($user->id != $class_students_student->fk_user_id){
            return response()->json([
                'message' => 'A inscrição do aluno não pertence ao aluno logado.'
            ], 202);
        }

        //falta verificar se possui alguma restrição de dependência

        $class_students_student->delete();

        return response()->json([
            'message' => 'A inscrição '.$class_students_student->id.' foi excluída.',
            $class_students_student
        ], 200);
    }

    //trazer informações (nome de professores e alunos) da turma
    public function details($id)
    {
        if (!$id) {
            return response()->json([
                'message' => 'Informe o código da turma.'
            ], 202);
        }

        $class_verify = ClassQuestione::where('id', $id)->first();

        if (!$class_verify) {
            return response()->json([
                'message' => 'A Turma não foi encontrada.'
            ], 202);
        }

        $user = auth('api')->user();

        $class_students = ClassStudents::where('fk_class_id', $class_verify->id)
            ->with('user')
            ->get();

        //$arr = array();
        $students = array();
        foreach ($class_students as $class_s){
            $student = (object)[
                'name' => mb_convert_case($class_s->user->name, MB_CASE_TITLE, 'UTF-8'),
                'id' => $this->iniciais($class_s->user->name),
                'email' => $class_s->user->email,
                'fk_class_id' => $class_s->fk_class_id,
                'active' => $class_s->active,
            ];
            $students[] = $student;
        }

        $class_questione = ClassQuestione::where('id', $class_verify->id)
            ->with('user')
            ->first();

        $professor = (object)[
            'name' => $class_questione->user->name,
            'id' => $this->iniciais($class_questione->user->name),
        ];
        sort($students);

        $arr = (object)[
            'professor' => $professor,
            'students' => $students,
        ];

        //sort($arr);

        //$object = (object) $arr;

        return response()->json($arr, 200);
    }

    public function iniciais($nome){
        $nome = preg_split("/((de|da|do|dos|das)?)[\s,_-]+/", $nome);
        $iniciais = "";
        foreach($nome as $n)
        {
            if (strlen($n) > 0)
            {
                $iniciais .= $n[0];
            }
        }
        return substr($iniciais, 0, 2);
    }

}
